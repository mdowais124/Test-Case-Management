import { Component, OnInit, ViewChild } from '@angular/core';
import { Subscription } from 'rxjs';

import { NgForm } from '@angular/forms';
import { TestCase } from './test-case.model';

import { Router, ActivatedRoute } from '@angular/router';
import { SharedService } from '../shared.service';

@Component({
  selector: 'app-test-form',
  templateUrl: './test-case-form.component.html',
  styleUrls: ['./test-case-form.component.css']
})

export class TestFormComponent implements OnInit {
  @ViewChild('f') testForm : NgForm;
  subscription: Subscription;
  editIndex: number;
  editMode = false;
  editedTestCase: TestCase;
  
  constructor(private router: Router, private sharedService: SharedService, private route: ActivatedRoute) {}

  ngOnInit() {
    this.editIndex = +this.route.snapshot.params['index'];
    this.editMode = this.sharedService.getEditMode();
    if(this.editMode == true) {
        this.editedTestCase = this.sharedService.getTestCase(this.editIndex);
        setTimeout(() => {
          this.testForm.setValue({
                testid: this.editedTestCase.testid,
                testPriority: this.editedTestCase.testPriority,
                testDesignedBy: this.editedTestCase.testDesignedBy,
                testExecutedBy: this.editedTestCase.testExecutedBy,
                testTitle: this.editedTestCase.testTitle,
                testSteps: this.editedTestCase.testSteps,
                expectedResult: this.editedTestCase.expectedResult,
                actualResult: this.editedTestCase.actualResult,
                testSummary: this.editedTestCase.testSummary
            });
        });
    }
  }
  
  onSubmit(form: NgForm) {
    const value = form.value;
    const newTestCase = new TestCase(value.testid, 
                                     value.testPriority,
                                     value.testDesignedBy,
                                     value.testExecutedBy,
                                     value.testTitle,
                                     value.testSteps,
                                     value.expectedResult,
                                     value.actualResult,
                                     value.testSummary);
    if(this.editMode) { 
      this.sharedService.updateTestCase(this.editIndex, newTestCase);
      alert('Test Case Updated Successfully');
    } else {
    this.sharedService.storeTestCase(newTestCase);
    alert('Test Case Added Successfully');
    }
    this.editMode = false;
    form.reset();
    this.router.navigate(['']);
    
  }
  
  onDelete() {
    this.sharedService.deleteTestCase(this.editIndex);
    this.onClear();
    alert("Test Case deleted successfully");
    this.router.navigate(['']);
  }
  
  onClear() {
    this.testForm.reset();
    this.editMode = false;
  }

}
