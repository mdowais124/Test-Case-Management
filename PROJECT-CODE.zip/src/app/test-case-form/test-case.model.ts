export class TestCase {
    constructor(public testid: string, 
                public testPriority: string,
                public testDesignedBy: string,
                public testExecutedBy: string,
                public testTitle: string,
                public testSteps: string,
                public expectedResult: string,
                public actualResult: string,
                public testSummary: string,
                ) {}
}