import { Injectable } from '@angular/core';
import { TestCase } from './test-case-form/test-case.model';
import { Subject } from 'rxjs/Subject';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
    testCasesChanged = new Subject<TestCase[]>();
    editMode = false;

    private testCases: TestCase[]= [
        new TestCase('11AA', 'Low', 'Smith', 'Steve', 'Enter gmail Url', 'enter url in browser', 'redirected','redirected', 'Pass'),
        new TestCase('22BB', 'Medium', 'David', 'Warner', 'Goto gmail login', 'click on login', 'display login','display login', 'Pass'),
        new TestCase('33AA', 'High', 'Smith', 'Steve', 'logout of gmail', 'logout of gmail', 'redirected','redirected', 'Pass'),  
    ];

    setEditMode(mode: boolean) {
        this.editMode = mode;
    }
    
    getEditMode() {
        return this.editMode;
    }
    
    storeTestCase(testCase: TestCase) {
        this.testCases.push(testCase);
        console.log(this.testCases);
        this.testCasesChanged.next(this.testCases.slice());
    }
    
    getTestCases() {
        return this.testCases.slice();
    }
    
    getTestCase(index: number) {
        return this.testCases[index];
    }
    
    updateTestCase(index: number, newTestCase: TestCase) {
        this.testCases[index] = newTestCase;
        this.testCasesChanged.next(this.testCases.slice());
    }
    
    deleteTestCase(index: number) {
        this.testCases.splice(index, 1);
        this.testCasesChanged.next(this.testCases.slice());
    }
}