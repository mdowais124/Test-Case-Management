import { Component, OnInit, ViewChild } from '@angular/core';
import { TestCase } from '../test-case-form/test-case.model'; 

import {MatPaginator, MatTableDataSource, MatSort} from '@angular/material';
import { Router } from '@angular/router';

import { SharedService } from '../shared.service';

@Component({
  selector: 'app-test-table',
  templateUrl: './test-case-table.component.html',
  styleUrls: ['./test-case-table.component.css']
})
export class TestTableComponent implements OnInit {
  
  testArray: TestCase[];
  dataSource = new MatTableDataSource<TestCase>(this.testArray);

  displayedColumns: string[] = ['testid', 'testPriority', 'testTitle', 'testSummary' , 'delete'];
  
   @ViewChild(MatPaginator) paginator: MatPaginator;
   @ViewChild(MatSort) sort: MatSort;

  constructor(private sharedService: SharedService, private router: Router) {}

  ngOnInit() {
    this.testArray = this.sharedService.getTestCases();
    this.dataSource.data = this.testArray;
    
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  
  routeToForm() {
    this.sharedService.setEditMode(false);
    this.router.navigate(['form']);
  }
  
  onEditTestCase(index: number){
    this.sharedService.setEditMode(true);
    this.router.navigate(['form', {index}]);
  }
  
  onDelete(index: number) {
    this.sharedService.deleteTestCase(index);
    this.ngOnInit();
  }

}
